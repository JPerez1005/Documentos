package com.inmobiliaria.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoInmobiliariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
