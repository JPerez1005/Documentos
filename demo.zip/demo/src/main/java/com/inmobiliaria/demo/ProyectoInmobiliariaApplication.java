package com.inmobiliaria.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoInmobiliariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoInmobiliariaApplication.class, args);
	}

}
